# Employee HR Data — Statistical Exploratory Data Analysis

> A complete end-to-end EDA pipeline built in R, uncovering workforce patterns across salary, performance, job satisfaction, and department composition through statistical analysis and professional data visualisation.

\---

## Author

**Mbali Fezeka Dlamini**  
Computer Science Student  
[!\[LinkedIn](https://www.linkedin.com/in/mbali-fezeka-dlamini-8938413aa/)
[!\[GitHub](https://github.com/Mbali242)

\---

## Tools \& Libraries

|Tool|Purpose|
|-|-|
|**R**|Core programming language|
|**ggplot2**|Data visualisation|
|**dplyr**|Data manipulation \& summarisation|
|**tidyr**|Data reshaping (wide ↔ long format)|
|**corrplot**|Correlation matrix heatmap|
|**scales**|Number formatting (commas, currency)|

\---

## Project Structure

```
employee-eda-r/
├── analysis.R                        # Main R script — full EDA pipeline
├── README.md                         # Project documentation
└── plots/
    ├── 01\_correlation\_matrix.png
    ├── 02\_salary\_distribution.png
    ├── 03\_salary\_by\_department.png
    ├── 04\_salary\_vs\_experience.png
    ├── 05\_performance\_by\_gender.png
    ├── 06\_employee\_count.png
    └── 07\_satisfaction\_vs\_performance.png
```

\---

## Dataset

The dataset is synthetically generated using R's random number functions (`rnorm`, `runif`, `sample`), simulating a realistic HR employee dataset with 8 variables across 200 records.

|Variable|Type|Description|Range|
|-|-|-|-|
|`employee\_id`|Integer|Unique employee identifier|1 – 200|
|`department`|Categorical|Business unit|Engineering, Marketing, Sales, HR, Finance|
|`age`|Numeric|Employee age|22 – 65|
|`salary`|Numeric|Annual salary (ZAR)|R30,000 – R120,000|
|`experience\_yrs`|Numeric|Years of professional experience|1 – 20|
|`performance`|Numeric|Performance review score|40 – 100|
|`satisfaction`|Numeric|Job satisfaction rating|1 – 10|
|`gender`|Categorical|Employee gender|Male / Female|

> \*\*Reproducibility:\*\* `set.seed(42)` ensures identical results on every run.

\---

## Analysis Overview

### 1\. Descriptive Statistics

Computed mean, median, standard deviation, minimum, and maximum for all numeric variables using `dplyr`'s `across()` function and reshaped with `tidyr` for a clean summary table.

### 2\. Correlation Analysis

Generated a Pearson correlation matrix across all numeric variables and visualised it as a colour-coded heatmap using `corrplot`, highlighting the strength and direction of relationships between variables.

### 3\. Visualisations

|#|Chart|Type|Key Question|
|-|-|-|-|
|1|Salary Distribution|Histogram + density curve|How is salary spread across employees?|
|2|Salary by Department|Boxplot + jitter|Which department pays the most/least?|
|3|Salary vs Experience|Scatter + regression line (95% CI)|Does experience predict salary?|
|4|Performance by Gender|Density plot|Do performance scores differ by gender?|
|5|Employee Count|Horizontal bar chart|How is headcount distributed?|
|6|Satisfaction vs Performance|Scatter + trend line|Do happier employees perform better?|

### 4\. Hypothesis Testing

|Test|Variables|Null Hypothesis|
|-|-|-|
|**Independent t-test**|Salary × Gender|No salary difference between genders|
|**Pearson Correlation Test**|Experience × Salary|No significant correlation|
|**One-Way ANOVA**|Performance × Department|No performance difference across departments|

\---

## &#x20;Key Findings

* Salary follows a **near-normal distribution** with a mean of R60,184 and SD of R15,344
* **HR has the highest median salary**; Finance has the lowest across all departments
* Years of experience show a **weak positive relationship** with salary — experience alone is not a strong predictor
* **Male and female performance scores are nearly identical**, with less than 1 point difference in means
* **Engineering is the largest department** (49 employees); Sales is the smallest (27)
* Job satisfaction shows **no statistically significant impact** on performance scores

\---

## How to Run

**Prerequisites:** R (≥ 4.0) and optionally RStudio

```bash
# 1. Clone the repository
git clone https://github.com/Mbali242/employee-eda-r.git
cd employee-eda-r

# 2. Open analysis.R in RStudio and run it
#    Required packages install automatically if missing
```

All plots are saved to the `/plots` folder. To view them interactively in RStudio, add `print(p1)` through `print(p6)` after each `ggsave()` call.





